// DAY 3 TODO: build using the browser's MediaRecorder API to record audio,
// plus a file-upload fallback. On submit, call api/client.js's submitAudio()
// with the audio Blob, a transcript field, dialect, and consent.
// Keep it simple per the roadmap: "browser recording or audio upload is
// enough" for week 1 — no streaming needed yet.

export default function ContributeVoice() {
  return (
    <section className="section">
      <h2>Contribute your voice</h2>
      <div className="card">
        Recording/upload interface coming Day 3.
      </div>
    </section>
  );
}
