// DAY 5 TODO: build the reviewer list + detail view.
// listSubmissions() from api/client.js already returns mock data you can
// render right now if you want to get a head start — a list of
// submission-row cards (see global.css .submission-row) linking to
// /review/:id, each showing type, dialect, status badge, and a preview.

export default function Review() {
  return (
    <section className="section">
      <h2>Review submissions</h2>
      <div className="card">
        Reviewer dashboard coming Day 5.
      </div>
    </section>
  );
}
