// DAY 2 TODO: build this following the exact same pattern as ContributeText.jsx.
// Fields needed (per the API contract): sourceText, targetText, sourceLanguage,
// targetLanguage, dialect, consent. Add a toggle for English->Tiv vs Tiv->English.
// Call api/client.js's submitTranslation() on submit.

export default function ContributeTranslation() {
  return (
    <section className="section">
      <h2>Contribute a translation</h2>
      <div className="card">
        Form coming Day 2 — see ContributeText.jsx for the pattern to follow.
      </div>
    </section>
  );
}
